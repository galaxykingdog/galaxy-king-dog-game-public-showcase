let pohpDownloadText;
// Galaxy King Dog — “Arcade High‑Score” Final Main.js
// Phaser v3.55.2
//
// Features kept + polished:
// ✅ Infinite waves + Galaxian/Galaga gentle ramp per wave (speed / fire rate / bullet speed)
// ✅ “Thin‑out” speed-up (when few enemies remain)
// ✅ Max 3 player bullets on screen
// ✅ Stable respawn FSM + invulnerability blink (1.6s)
// ✅ START icon blink + 3‑2‑1 countdown + GAME OVER image
// ✅ HI‑SCORE (persistent) + TOP5 (persistent) + Blockchain submit stub (B key)
// ✅ Audio: BGM loop + enemy move loop + enemy dive loop + player shoot SFX
//
// Assets expected in /assets:
// backround1.jpg, ship.png, enemy_*.png, bullet_*.png, explosion.png, boom.png
// start_game.png, assets3.png assets2.png assets1.png, gameover.png
// sfx_laser1.ogg, sfx_enemy_move_loop.wav, sfx_enemy_dive_loop.wav, bgm_galaxy_mystery_loop.wav

// =================== CONFIG ===================
document.title = 'DOG KING (POHP v3)';

const config = {
  type: Phaser.AUTO,
  width: 800,
  height: 600,
  parent: 'game-container',
  backgroundColor: '#000011',
  scale: { mode: Phaser.Scale.FIT, autoCenter: Phaser.Scale.CENTER_BOTH },
  render: { pixelArt: true, antialias: false, roundPixels: true },
  physics: {
    default: 'arcade',
    arcade: { gravity: { y: 0 }, debug: false }
  },
  scene: { preload, create, update }
};

// =================== GAME PHASE ===================
const GAME_PHASE = {
  START: 0,
  COUNTDOWN: 1,
  RUNNING: 2,
  GAME_OVER: 3
};
let gamePhase = GAME_PHASE.START;

// =================== TUNING (easy knobs) ===================
// If you want “half difficulty”, lower this to 0.50.
const DIFFICULTY_SCALE = 0.85;

// Enemy speeds: x3.5 slower (your earlier request)
const ENEMY_SPEED_FACTOR = 1 / 3.5;

// Enemy chance (dive + shooting): x3 more frequent (your earlier request)
const ENEMY_CHANCE_FACTOR = 1.5;

// Galaxian/Galaga gentle ramps per wave
const PER_WAVE_SPEED_UP = 0.035;     // +3.5% / wave
const PER_WAVE_BULLET_UP = 0.030;    // +3% / wave
const PER_WAVE_RATE_UP  = 0.025;     // +5% / wave

// Thin-out speed-up (when few enemies remain)
const THIN_OUT_SPEED_UP  = 0.55;     // up to +110% move speed
const THIN_OUT_RATE_UP   = 0.85;     // up to +85% fire rate
const THIN_OUT_BULLET_UP = 0.25;     // up to +25% bullet speed

function waveSpeedMul(w)  { return 1 + (w - 1) * PER_WAVE_SPEED_UP; }
function waveBulletMul(w) { return 1 + (w - 1) * PER_WAVE_BULLET_UP; }
function waveRateMul(w)   { return 1 + (w - 1) * PER_WAVE_RATE_UP; }

// =================== START / COUNTDOWN UI ===================
const START_ICON_TARGET_W = 600;
const START_ICON_TARGET_H = 300;
const START_ICON_Y = 300;
const COUNTDOWN_SIZE_SCALE = 1.93;

let startIcon = null;
let gameOverImage = null;
let countdownSprites = [];
let countdownInProgress = false;

// =================== AUDIO (mix knobs) ===================
const BGM_VOLUME = 0.28;             // background music volume
const SFX_SHOOT_VOLUME = 0.45;       // player shoot
const SFX_HIT_VOLUME = 0.55;         // player hit
const SFX_ENEMY_MOVE_VOL = 0.22;     // continuous “formation move” hum
const SFX_ENEMY_DIVE_VOL = 0.28;     // continuous “dive” loop hum

let audioUnlocked = false;
let bgm = null;
let sfxPlayerShoot = null;
let sfxHitShip = null;
let sfxEnemyMoveLoop = null;
let sfxEnemyDiveLoop = null;

// =================== PLAYER FSM ===================
const PLAYER_STATE = {
  PLAYING: 0,
  DYING: 1,
  RESPAWNING: 2,
  GAME_OVER: 3
};

let playerState = PLAYER_STATE.PLAYING;
let respawnTimer = 0;
let invulnerabilityTimer = 0;

const RESPAWN_DELAY = 800;     // ms
const INVULN_DURATION = 1600;  // ms  ✅ (your request: longer blink invulnerable)
const MAX_PLAYER_BULLETS_ONSCREEN = 3;

// =================== GLOBALS ===================
let game;
let mainScene;

let player;
let enemies;
let enemyBullets;
let playerBullets;
let stars;

let score = 0;
let highScore = 0;
let topScores = []; // [{score,wave,ts}]

let scoreText, livesText, waveText, highScoreText, topText, chainStatusText, pohpStatusText;
let lives = 3;
let wave = 1;

let cursors, spaceKey, restartKey, submitKey, proofKey;

let playerBulletEnemyCollider;
let enemyBulletPlayerCollider;
let enemyPlayerCollider;

let formationTotalAtWave = 0;

// last-life aura
let boomAura = null;

// =================== “BLOCKCHAIN” SUBMIT (STUB) ===================
const CHAIN_SUBMIT_URL = ""; // set later (e.g. "http://127.0.0.1:8787/submit-score")
const LS_HISCORE_KEY = "gkd_hiScore_v1";
const LS_TOP5_KEY    = "gkd_top5_v1";
const LS_PENDING_KEY = "gkd_chain_pending_v1";

// =================== ENEMY FORMATION ===================
const FORMATION_CENTER_X = 400;
const ENEMY_SPACING_X = 50;
const ENEMY_SPACING_Y = 44;
const ENEMY_START_Y = 90;
const FORMATION_Y_OFFSET = -40;

let enemyFormation = []; // 2D
let enemyDirection = 1;

// difficulty (set by applyWaveDifficulty)
let enemySpeedBase = 30;
let enemyDiveBaseChance = 0.001;
let enemyBulletBaseChance = 0.0004;
const MAX_DIVING_ENEMIES = 6;

// rotation feel during dive
// If your enemy art points DOWN at rotation 0, keep this = -Math.PI/2
// If it points RIGHT, use 0
// If it points UP, use Math.PI/2
const ENEMY_ROT_OFFSET = -Math.PI / 2;
const ENEMY_FORMATION_ROT = Math.PI; // face DOWN in formation (if your art already faces down, set 0)
const ENEMY_DIVE_ROT      = ENEMY_FORMATION_ROT; // keep face DOWN during dive/attack
const ENEMY_RETURN_ROT    = ENEMY_FORMATION_ROT + Math.PI; // face UP while returning to formation
const ENEMY_ROT_SPEED_DIVE   = 10.0; // rad/sec turn speed while diving
const ENEMY_ROT_SPEED_RETURN = 8.0;  // rad/sec turn speed when returning

// scores
const ENEMY_SCORES = { flagship: 150, red: 100, purple: 80, blue: 30 };

// =================== HELPERS ===================
function setColliderActive(c, on) { if (c) c.active = !!on; }

function disablePlayerPhysics(p) {
  if (!p) return;
  p.setActive(false);
  p.setVisible(false);
  p.setVelocity(0, 0);
  if (p.body) {
    p.body.enable = false;
    p.body.setVelocity(0, 0);
  }
}

function enablePlayerPhysics(p, x, y) {
  if (!p) return;
  p.setPosition(x, y);
  p.setActive(true);
  p.setVisible(true);
  p.setAlpha(1);

  // critical respawn fix
  if (p.body) {
    p.body.enable = true;
    p.body.reset(x, y);
    p.body.setVelocity(0, 0);
  }
  p.setCollideWorldBounds(true);
}

function safeJSONParse(str, fallback) {
  try { return JSON.parse(str); } catch { return fallback; }
}

function loadScores() {
  try {
    const hs = parseInt(localStorage.getItem(LS_HISCORE_KEY) || "0", 10);
    highScore = Number.isFinite(hs) ? hs : 0;

    const arr = safeJSONParse(localStorage.getItem(LS_TOP5_KEY) || "[]", []);
    topScores = Array.isArray(arr) ? arr : [];
    topScores = topScores.filter(x => x && Number.isFinite(x.score)).slice(0, 5);
  } catch {
    highScore = 0;
    topScores = [];
  }
}

function saveScores() {
  try {
    localStorage.setItem(LS_HISCORE_KEY, String(highScore));
    localStorage.setItem(LS_TOP5_KEY, JSON.stringify(topScores.slice(0, 5)));
  } catch { /* ignore */ }
}

function maybeUpdateHighScore() {
  if (score > highScore) {
    highScore = score;
    return true;
  }
  return false;
}

function pushTopScore(s, w) {
  const entry = { score: s, wave: w, ts: Date.now() };
  topScores.push(entry);
  topScores.sort((a, b) => b.score - a.score);
  topScores = topScores.slice(0, 5);
}

function formatTopScores() {
  if (!topScores.length) return "TOP 5:\n—";
  const lines = ["TOP 5:"];
  for (let i = 0; i < topScores.length; i++) {
    const e = topScores[i];
    lines.push(`${i + 1}. ${e.score}  (W${e.wave})`);
  }
  return lines.join("\n");
}

// Hash helpers (blockchain payload)
function fnv1a32(str) {
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return ("00000000" + (h >>> 0).toString(16)).slice(-8);
}

async function sha256Hex(str) {
  if (!window.crypto || !crypto.subtle) return fnv1a32(str);
  const buf = new TextEncoder().encode(str);
  const hash = await crypto.subtle.digest("SHA-256", buf);
  return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, "0")).join("");
}

// =================== PROOF OF HIGH PLAY (Seeded RNG + Input Log + Run Package + Replay Verify) ===================
// Goal: keep gameplay rules the same, but make runs replayable & verifiable.
// - NO nondeterministic random() anywhere (we use seeded RNG streams)
// - Record: (inputs per frame) + (delta ms per frame) + (seed)
// - Export: runPackage.json on GAME OVER
// - Replay mode: ?replay=1 lets you load runPackage.json and re-simulate to PASS/FAIL score.

const POHP_SCHEMA_VERSION = 1;
const POHP_GAME_ID = "420_HIGH_SCORE_GALAXIAN";   // metadata only (does not affect gameplay)
const POHP_GAME_VERSION = "main.js_v1.0.0";       // bump when you change gameplay-affecting logic

// (Chain fields placeholders for later Solana integration)
const POHP_DEFAULT_SEASON_ID = 1;
const POHP_DEFAULT_FEE_LAMPORTS = 0;

let POHP_SEASON_ID = POHP_DEFAULT_SEASON_ID;
let POHP_FEE_LAMPORTS = POHP_DEFAULT_FEE_LAMPORTS;
let POHP_ENTRY_SIG = "";
let POHP_ENTRY_SLOT = 0;

let POHP_PLAYER_PUBKEY = ""; // set from connected wallet (base58) for serious runs

// Small global API so blockchain/solana code can plug-in without touching gameplay.
window.POHP = window.POHP || {};
window.POHP.setPlayerPubkey = (pk) => { POHP_PLAYER_PUBKEY = (pk || "").toString(); };
window.POHP.setSeasonId = (sid) => {
  const n = Number(sid);
  POHP_SEASON_ID = Number.isFinite(n) ? n : POHP_DEFAULT_SEASON_ID;
};
window.POHP.setEntryProof = ({ fee_lamports = 0, entry_sig = "", entry_slot = 0 } = {}) => {
  POHP_FEE_LAMPORTS = Number(fee_lamports) || 0;
  POHP_ENTRY_SIG = (entry_sig || "").toString();
  POHP_ENTRY_SLOT = Number(entry_slot) || 0;
};


// Input bits per frame
const POHP_INPUT_BITS = { LEFT: 1, RIGHT: 2, SHOOT: 4 };

// Runtime state
let POHP_runSeed = 0;
let POHP_runStartTs = 0;
let POHP_runEndTs = 0;

// Two independent RNG streams:
// - Visual RNG: stars etc. (never affects gameplay RNG sequence)
// - Game RNG: ONLY gameplay-critical randomness (dives, bullet speed, enemy pick)
let POHP_rngVisual = null;
let POHP_rngGame = null;

function POHP_mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a += 0x6D2B79F5;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t ^= t + Math.imul(t ^ (t >>> 7), 61 | t);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function POHP_u32Seed() {
  try {
    if (window.crypto && crypto.getRandomValues) {
      const u = new Uint32Array(1);
      crypto.getRandomValues(u);
      return u[0] >>> 0;
    }
  } catch { /* ignore */ }
  // deterministic-ish fallback (still deterministic)
  return (Date.now() >>> 0) ^ 0xA5A5A5A5;
}

function POHP_initVisualRngOnce() {
  if (POHP_rngVisual) return;
  POHP_rngVisual = POHP_mulberry32(POHP_u32Seed());
}

function POHP_setGameRng(seedU32) {
  POHP_rngGame = POHP_mulberry32(seedU32 >>> 0);
}

function POHP_vrFloat() { return POHP_rngVisual ? POHP_rngVisual() : 0.5; }
function POHP_grFloat() { return POHP_rngGame ? POHP_rngGame() : 0.5; }

function POHP_vrBetween(min, max) {
  const r = POHP_vrFloat();
  return Math.floor(r * (max - min + 1)) + min;
}
function POHP_vrFloatBetween(min, max) {
  return min + POHP_vrFloat() * (max - min);
}

function POHP_grBetween(min, max) {
  const r = POHP_grFloat();
  return Math.floor(r * (max - min + 1)) + min;
}
function POHP_grFloatBetween(min, max) {
  return min + POHP_grFloat() * (max - min);
}
function POHP_grPick(arr) {
  if (!arr || arr.length === 0) return null;
  const i = Math.floor(POHP_grFloat() * arr.length);
  return arr[i];
}

// Recorder (LIVE mode)
const POHP_record = {
  active: false,
  masks: [],   // number[] (0..7)
  deltas: [],  // number[] (ms)
  prevMask: 0
};

// Replay (VERIFY mode)
const POHP_replay = {
  requested: false,  // ?replay=1
  enabled: false,
  loaded: false,
  frame: 0,
  simTimeMs: 0,
  masks: null,   // Uint8Array
  deltas: null,  // Uint16Array
  expectedScore: 0,
  expectedWave: 0,
  packageReplayHash: "",
  packageRunHash: "",
  packageVersionHash: "",
  hashOk: null,   // null | true | false
  // internal: cached copies for integrity check
  masks_b64: "",
  deltas_b64: "",
  seed: 0
};

// Last built run package (built on Game Over; downloaded via user gesture)
let POHP_lastPackage = null;
let POHP_lastPackageName = "";
let POHP_lastPackageReady = false;

// Per-frame input state (shared by live + replay)
const POHP_input = {
  mask: 0,
  prevMask: 0,
  left: false,
  right: false,
  shoot: false,
  shootJust: false
};

function POHP_isReplayRequested() {
  try {
    const qs = new URLSearchParams(window.location.search);
    return qs.get("replay") === "1";
  } catch { return false; }
}

// --- base64 packing helpers (compact runPackage) ---
function POHP_u8ToB64(u8) {
  let bin = "";
  for (let i = 0; i < u8.length; i++) bin += String.fromCharCode(u8[i]);
  return btoa(bin);
}
function POHP_b64ToU8(b64) {
  const bin = atob(b64);
  const u8 = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i) & 0xff;
  return u8;
}
function POHP_u16ToB64(u16) {
  const bytes = new Uint8Array(u16.length * 2);
  for (let i = 0; i < u16.length; i++) {
    const v = u16[i] & 0xffff;
    bytes[i * 2] = v & 0xff;
    bytes[i * 2 + 1] = (v >>> 8) & 0xff;
  }
  return POHP_u8ToB64(bytes);
}
function POHP_b64ToU16(b64) {
  const bytes = POHP_b64ToU8(b64);
  const n = Math.floor(bytes.length / 2);
  const out = new Uint16Array(n);
  for (let i = 0; i < n; i++) {
    out[i] = (bytes[i * 2] | (bytes[i * 2 + 1] << 8)) & 0xffff;
  }
  return out;
}

function POHP_downloadJSON(filename, obj) {
  try {
    const blob = new Blob([JSON.stringify(obj)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  } catch (e) {
    console.log("RUN PACKAGE:", obj);
  }
}


function POHP_tryDownloadLatest() {
  try {
    if (POHP_lastPackageReady && POHP_lastPackage && POHP_lastPackageName) {
      POHP_downloadJSON(POHP_lastPackageName, POHP_lastPackage);
      if (pohpStatusText) pohpStatusText.setText('PROOF: downloaded ✅  (' + POHP_lastPackageName + ')');
      return true;
    }
    // If user refreshed, try recover from localStorage
    const n = localStorage.getItem('pohp_last_runPackage_name');
    const j = localStorage.getItem('pohp_last_runPackage_json');
    if (n && j) {
      POHP_downloadJSON(n, JSON.parse(j));
      if (pohpStatusText) pohpStatusText.setText('PROOF: downloaded ✅  (' + n + ')');
      return true;
    }
    if (pohpStatusText) pohpStatusText.setText('PROOF: not ready yet (finish a run first)');
    return false;
  } catch (e) {
    if (pohpStatusText) pohpStatusText.setText('PROOF: download blocked — check Ctrl+J (Downloads)');
    return false;
  }
}


function POHP_readLiveMask() {
  let m = 0;
  if (cursors && cursors.left && cursors.left.isDown) m |= POHP_INPUT_BITS.LEFT;
  if (cursors && cursors.right && cursors.right.isDown) m |= POHP_INPUT_BITS.RIGHT;
  if (spaceKey && spaceKey.isDown) m |= POHP_INPUT_BITS.SHOOT;
  return m;
}

// Called at the start of each RUN (beginGame)
function POHP_beginRunSession() {
  POHP_runStartTs = Date.now();
  POHP_runEndTs = 0;

  POHP_record.prevMask = 0;
  POHP_input.mask = 0;
  POHP_input.prevMask = 0;

  // Replay run uses the seed embedded in the package
  if (POHP_replay.enabled && POHP_replay.loaded) {
    POHP_runSeed = (POHP_replay.seed >>> 0);
    POHP_setGameRng(POHP_runSeed);
    POHP_record.active = false;
    return;
  }

  // Live run: new seed, start recording frames
  POHP_runSeed = POHP_u32Seed();
  POHP_setGameRng(POHP_runSeed);

  POHP_record.masks = [];
  POHP_record.deltas = [];
  POHP_record.active = true;
}

// Replay step override: use recorded delta/time and recorded input mask
function POHP_replayOverrideTimeDelta(time, delta) {
  if (!(POHP_replay.enabled && POHP_replay.loaded)) return { time, delta };

  const d = POHP_replay.deltas[POHP_replay.frame] || 16;
  POHP_replay.simTimeMs += d;
  return { time: POHP_replay.simTimeMs, delta: d };
}

function POHP_advanceInputsAndRecord(deltaMs) {
  POHP_input.prevMask = POHP_input.mask;

  if (POHP_replay.enabled && POHP_replay.loaded) {
    POHP_input.mask = (POHP_replay.frame < POHP_replay.masks.length) ? POHP_replay.masks[POHP_replay.frame] : 0;
  } else {
    POHP_input.mask = POHP_readLiveMask();
  }

  const m = POHP_input.mask;
  const pm = POHP_input.prevMask;

  POHP_input.left = !!(m & POHP_INPUT_BITS.LEFT);
  POHP_input.right = !!(m & POHP_INPUT_BITS.RIGHT);
  POHP_input.shoot = !!(m & POHP_INPUT_BITS.SHOOT);
  POHP_input.shootJust = POHP_input.shoot && !(pm & POHP_INPUT_BITS.SHOOT);

  // Record only during live run while RUNNING
  if (POHP_record.active) {
    POHP_record.masks.push(m & 0xff);
    const d = Math.max(0, Math.min(65535, Math.round(deltaMs)));
    POHP_record.deltas.push(d);
  }

  // Replay advances one frame per simulation step
  if (POHP_replay.enabled && POHP_replay.loaded) {
    POHP_replay.frame += 1;
  }
}

async function POHP_buildRunPackage(finalScore, finalWave) {
  const versionHash = await sha256Hex(POHP_GAME_VERSION);
  const seedCommit = await sha256Hex("seed:" + String(POHP_runSeed >>> 0));

  const masksU8 = new Uint8Array(POHP_record.masks);
  const deltasU16 = new Uint16Array(POHP_record.deltas);

  const masks_b64 = POHP_u8ToB64(masksU8);
  const deltas_b64 = POHP_u16ToB64(deltasU16);

  const replayMaterial = JSON.stringify({
    schema: POHP_SCHEMA_VERSION,
    game_id: POHP_GAME_ID,
    version_hash: versionHash,
    seed: POHP_runSeed >>> 0,
    masks_b64,
    deltas_b64
  });

  const replay_hash = await sha256Hex(replayMaterial);

  const runMaterial = [
    POHP_PLAYER_PUBKEY || "",
    POHP_GAME_ID,
    String(POHP_SEASON_ID),
    String(POHP_FEE_LAMPORTS),
    POHP_ENTRY_SIG || "",
    String(POHP_ENTRY_SLOT),
    String(finalScore),
    replay_hash,
    versionHash
  ].join("|");

  const run_hash = await sha256Hex(runMaterial);

  return {
    schema: POHP_SCHEMA_VERSION,
    game_id: POHP_GAME_ID,
    game_version: POHP_GAME_VERSION,
    version_hash: versionHash,

    player_pubkey: POHP_PLAYER_PUBKEY || "",
    season_id: POHP_SEASON_ID,
    fee_lamports: POHP_FEE_LAMPORTS,
    entry_sig: POHP_ENTRY_SIG || "",
    entry_slot: POHP_ENTRY_SLOT,

    start_ts: POHP_runStartTs,
    end_ts: POHP_runEndTs || Date.now(),

    seed: POHP_runSeed >>> 0,
    seed_commit: seedCommit,

    final_score: finalScore,
    final_wave: finalWave,

    masks_len: masksU8.length,
    deltas_len: deltasU16.length,
    masks_b64,
    deltas_b64,

    replay_hash,
    run_hash
  };
}

async function POHP_exportRunPackageOnGameOver(finalScore, finalWave) {
  POHP_runEndTs = Date.now();
  POHP_record.active = false;

  const pkg = await POHP_buildRunPackage(finalScore, finalWave);
  const fname = `runPackage_${POHP_GAME_ID}_score${finalScore}_ts${POHP_runStartTs}.json`;
  POHP_downloadJSON(fname, pkg);
  return pkg;
}

async function POHP_finalizeRunPackageOnGameOver(finalScore, finalWave) {
  POHP_runEndTs = Date.now();
  POHP_record.active = false;
  POHP_lastPackageReady = false;

  const pkg = await POHP_buildRunPackage(finalScore, finalWave);
  POHP_lastPackage = pkg;
  POHP_lastPackageName = `runPackage_${POHP_GAME_ID}_score${finalScore}_ts${POHP_runStartTs}.json`;
  POHP_lastPackageReady = true;

  // Also stash last package in localStorage as backup (download can be blocked by browsers if not user-triggered)
  try {
    localStorage.setItem("pohp_last_runPackage_name", POHP_lastPackageName);
    localStorage.setItem("pohp_last_runPackage_json", JSON.stringify(pkg));
  } catch {}
  return pkg;
}

async function POHP_verifyLoadedPackage() {
  try {
    const versionHash = await sha256Hex(POHP_GAME_VERSION);
    const replayMaterial = JSON.stringify({
      schema: POHP_SCHEMA_VERSION,
      game_id: POHP_GAME_ID,
      version_hash: versionHash,
      seed: POHP_replay.seed >>> 0,
      masks_b64: POHP_replay.masks_b64,
      deltas_b64: POHP_replay.deltas_b64
    });
    const replay_hash = await sha256Hex(replayMaterial);
    POHP_replay.hashOk = (replay_hash === POHP_replay.packageReplayHash);
  } catch {
    POHP_replay.hashOk = null;
  }
}

// UI loader for replay packages (?replay=1)
function POHP_setupReplayLoader(scene) {
  POHP_replay.requested = true;

  const t = scene.add.text(
    400, 520,
    "REPLAY MODE: choose runPackage.json\n(Score will be recomputed and checked)",
    { fontSize: "16px", fill: "#0f0", fontFamily: "Courier New", align: "center" }
  ).setOrigin(0.5).setDepth(20);

  const inp = document.createElement("input");
  inp.type = "file";
  inp.accept = "application/json";
  inp.style.position = "absolute";
  inp.style.left = "12px";
  inp.style.top = "12px";
  inp.style.zIndex = "9999";
  inp.style.padding = "6px";
  inp.style.background = "rgba(0,0,0,0.7)";
  inp.style.color = "#0f0";
  inp.style.border = "1px solid #0f0";

  document.body.appendChild(inp);

  inp.addEventListener("change", async () => {
    const f = inp.files && inp.files[0];
    if (!f) return;

    try {
      const raw = await f.text();
      const pkg = JSON.parse(raw);

      if (!pkg || pkg.schema !== POHP_SCHEMA_VERSION || !pkg.masks_b64 || !pkg.deltas_b64) {
        throw new Error("Invalid runPackage schema");
      }

      POHP_replay.enabled = true;
      POHP_replay.loaded = true;
      POHP_replay.frame = 0;
      POHP_replay.simTimeMs = 0;

      POHP_replay.expectedScore = pkg.final_score | 0;
      POHP_replay.expectedWave = pkg.final_wave | 0;

      POHP_replay.seed = (pkg.seed >>> 0);

      POHP_replay.packageReplayHash = String(pkg.replay_hash || "");
      POHP_replay.packageRunHash = String(pkg.run_hash || "");

      POHP_replay.masks_b64 = String(pkg.masks_b64);
      POHP_replay.deltas_b64 = String(pkg.deltas_b64);

      POHP_replay.masks = POHP_b64ToU8(POHP_replay.masks_b64);
      POHP_replay.deltas = POHP_b64ToU16(POHP_replay.deltas_b64);

      POHP_setGameRng(POHP_replay.seed);

      POHP_verifyLoadedPackage();

      try { inp.remove(); } catch {}
      try { t.destroy(); } catch {}

      unlockAudioOnce(scene);
      beginGame(scene);
    } catch (e) {
      console.error(e);
      t.setText("REPLAY MODE: invalid runPackage.json\nCheck console for details");
    }
  });
}


function buildScorePayload() {
  return { game: "GalaxyKingDog", version: "1.0", score, wave, ts: Date.now() };
}

async function submitScoreToChain() {
  const payload = buildScorePayload();
  const raw = JSON.stringify(payload);
  const hash = await sha256Hex(raw);
  const envelope = { payload, hash };

  // keep pending locally always
  try {
    const pending = safeJSONParse(localStorage.getItem(LS_PENDING_KEY) || "[]", []);
    pending.unshift(envelope);
    localStorage.setItem(LS_PENDING_KEY, JSON.stringify(pending.slice(0, 25)));
  } catch { /* ignore */ }

  if (chainStatusText) chainStatusText.setText("CHAIN: saved locally (pending)");

  if (!CHAIN_SUBMIT_URL) {
    if (chainStatusText) chainStatusText.setText("CHAIN: pending (set CHAIN_SUBMIT_URL)");
    return;
  }

  try {
    if (chainStatusText) chainStatusText.setText("CHAIN: submitting...");
    const res = await fetch(CHAIN_SUBMIT_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(envelope)
    });
    if (!res.ok) throw new Error("HTTP " + res.status);
    if (chainStatusText) chainStatusText.setText("CHAIN: submitted ✅");
  } catch (e) {
    if (chainStatusText) chainStatusText.setText("CHAIN: submit failed (kept pending)");
  }
}

function aliveRatioNow() {
  if (!formationTotalAtWave) return 1;
  return Phaser.Math.Clamp(enemies.countActive(true) / formationTotalAtWave, 0, 1);
}

// =================== WAVE DIFFICULTY ===================
function applyWaveDifficulty(waveNum) {
  const baseSpeed        = 30 + (waveNum - 1) * 4;
  const baseDiveChance   = 0.001 + (waveNum - 1) * 0.0002;
  const baseBulletChance = 0.0008 + (waveNum - 1) * 0.00015;

  const sMul = waveSpeedMul(waveNum);
  const rMul = waveRateMul(waveNum);

  enemySpeedBase        = baseSpeed * ENEMY_SPEED_FACTOR * sMul * DIFFICULTY_SCALE;
  enemyDiveBaseChance   = baseDiveChance * ENEMY_CHANCE_FACTOR * (0.92 + 0.08 * rMul) * DIFFICULTY_SCALE;
  enemyBulletBaseChance = baseBulletChance * ENEMY_CHANCE_FACTOR * rMul * DIFFICULTY_SCALE;
}

// =================== PRELOAD ===================
function preload() {
  // images
  this.load.image('background',     'assets/backround1.jpg');
  this.load.image('ship',           'assets/ship.png');
  this.load.image('enemy_blue',     'assets/enemy_blue.png');
  this.load.image('enemy_red',      'assets/enemy_red.png');
  this.load.image('enemy_purple',   'assets/enemy_purple.png');
  this.load.image('enemy_flagship', 'assets/enemy_flagship.png');
  this.load.image('bullet_player',  'assets/bullet_player.png');
  this.load.image('bullet_enemy',   'assets/bullet_enemy.png');
  this.load.image('explosion',      'assets/explosion.png');
  this.load.image('boom',           'assets/boom.png');

  // start/countdown/gameover
  this.load.image('start_icon', 'assets/start_game.png');
  this.load.image('count3',     'assets/assets3.png');
  this.load.image('count2',     'assets/assets2.png');
  this.load.image('count1',     'assets/assets1.png');
  this.load.image('gameover',   'assets/gameover.png');

  // audio
  this.load.audio('bgm',                 'assets/bgm_galaxy_mystery_loop.wav');
  this.load.audio('sfx_player_shoot',    'assets/sfx_laser1.ogg');
  this.load.audio('sfx_hitship',         'assets/sfx_laser1.ogg'); // reuse (lower volume + rate)
  this.load.audio('sfx_enemy_move_loop', 'assets/sfx_enemy_move_loop.wav');
  this.load.audio('sfx_enemy_dive_loop', 'assets/sfx_enemy_dive_loop.wav');
}

// =================== AUDIO INIT (after first user gesture) ===================
function unlockAudioOnce(scene) {
  if (audioUnlocked) return;
  audioUnlocked = true;

  // create sounds (guard: only if loaded)
  if (scene.cache.audio.exists('bgm')) bgm = scene.sound.add('bgm', { loop: true, volume: 0 });
  if (scene.cache.audio.exists('sfx_player_shoot')) sfxPlayerShoot = scene.sound.add('sfx_player_shoot', { volume: SFX_SHOOT_VOLUME });
  if (scene.cache.audio.exists('sfx_hitship')) sfxHitShip = scene.sound.add('sfx_hitship', { volume: SFX_HIT_VOLUME, rate: 0.85 });

  if (scene.cache.audio.exists('sfx_enemy_move_loop')) sfxEnemyMoveLoop = scene.sound.add('sfx_enemy_move_loop', { loop: true, volume: 0 });
  if (scene.cache.audio.exists('sfx_enemy_dive_loop')) sfxEnemyDiveLoop = scene.sound.add('sfx_enemy_dive_loop', { loop: true, volume: 0 });

  // start loops silently (so later we only fade volume)
  if (bgm) bgm.play();
  if (sfxEnemyMoveLoop) sfxEnemyMoveLoop.play();
  if (sfxEnemyDiveLoop) sfxEnemyDiveLoop.play();
}

function setLoopVolume(snd, target) {
  if (!snd) return;
  const cur = snd.volume ?? 0;
  const next = Phaser.Math.Linear(cur, target, 0.08);
  snd.setVolume(next);
}

// =================== CREATE ===================
function create() {
  POHP_initVisualRngOnce();
  loadScores();
  mainScene = this;

  // background
  this.add.image(400, 300, 'background').setDisplaySize(800, 600);

  // starfield
  stars = this.add.group();
  for (let i = 0; i < 100; i++) {
    const star = this.add.rectangle(
      POHP_vrBetween(0, 800),
      POHP_vrBetween(0, 600),
      2, 2, 0xffffff
    );
    star.setAlpha(POHP_vrFloatBetween(0.3, 1));
    stars.add(star);
  }

  // groups
  enemies = this.physics.add.group();
  enemyBullets = this.physics.add.group();
  playerBullets = this.physics.add.group();

  // bullet pooling
  const MAX_PLAYER_BULLETS = 12;
  const MAX_ENEMY_BULLETS  = 32;

  for (let i = 0; i < MAX_PLAYER_BULLETS; i++) {
    const b = this.physics.add.sprite(-100, -100, 'bullet_player');
    b.setActive(false); b.setVisible(false);
    if (b.body) b.body.enable = false;
    playerBullets.add(b);
  }
  for (let i = 0; i < MAX_ENEMY_BULLETS; i++) {
    const b = this.physics.add.sprite(-100, -100, 'bullet_enemy');
    b.setActive(false); b.setVisible(false);
    if (b.body) b.body.enable = false;
    enemyBullets.add(b);
  }

  // player + formation
  createPlayer(this);
  createEnemyFormation(this);

  // input
  cursors    = this.input.keyboard.createCursorKeys();
  spaceKey   = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);
  restartKey = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.R);
  submitKey  = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.B);
  proofKey   = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.P);

  // UI
  const uiStyle = { fontSize: '20px', fill: '#0f0', fontFamily: 'Courier New' };
  scoreText = this.add.text(10, 10, 'SCORE: 0', uiStyle);
  livesText = this.add.text(10, 40, 'LIVES: 3', uiStyle);
  waveText  = this.add.text(10, 70, 'WAVE: 1',  uiStyle);
  highScoreText = this.add.text(10, 100, 'HI-SCORE: ' + highScore, uiStyle);
  topText = this.add.text(10, 130, formatTopScores(), { ...uiStyle, fontSize: '16px' });

  chainStatusText = this.add.text(10, 260, '', { fontSize: '14px', fill: '#0f0', fontFamily: 'Courier New' }).setDepth(50);
  pohpStatusText  = this.add.text(10, 290, '', { fontSize: '14px', fill: '#0f0', fontFamily: 'Courier New' }).setDepth(50);
  // POHP download button (shown on GAME OVER) — click works even if keyboard is weird
  pohpDownloadText = this.add.text(10, 320, '⬇ DOWNLOAD runPackage.json (click or press P)', { fontSize: '16px', fill: '#ff0', fontFamily: 'Courier New' })
    .setDepth(50)
    .setInteractive({ useHandCursor: true })
    .setVisible(false);
  pohpDownloadText.on('pointerdown', () => {
    POHP_tryDownloadLatest();
  });



  // game over image (hidden)
  gameOverImage = this.add.image(400, 300, 'gameover').setOrigin(0.5).setScale(0.85).setDepth(10).setVisible(false);

  // last-life aura
  boomAura = this.add.image(400, 550, 'boom')
    .setOrigin(0.5)
    .setScale(0.29)
    .setDepth(4)
    .setVisible(false);

  // collisions
  playerBulletEnemyCollider = this.physics.add.overlap(playerBullets, enemies, hitEnemy, null, this);
  enemyBulletPlayerCollider = this.physics.add.overlap(enemyBullets, player, hitPlayer, null, this);
  enemyPlayerCollider = this.physics.add.overlap(enemies, player, (enemy, playerObj) => hitPlayer(enemy, playerObj), null, this);

  respawnTimer = 0;
  invulnerabilityTimer = 0;

  // show start screen
  showStartScreen(this);

  // Optional replay verify mode: open index.html?replay=1
  if (POHP_isReplayRequested()) {
    POHP_setupReplayLoader(this);
  }
}

// =================== PLAYER CREATION ===================
function createPlayer(scene) {
  player = scene.physics.add.sprite(400, 550, 'ship');
  player.setCollideWorldBounds(true);
  player.setScale(0.8);
  player.setVelocity(0, 0);

  if (player.body) {
    player.body.enable = true;
    player.body.reset(400, 550);
    player.body.setVelocity(0, 0);
  }

  playerState = PLAYER_STATE.PLAYING;
  invulnerabilityTimer = 0;
  respawnTimer = 0;
}

// =================== ENEMY FORMATION CREATION ===================
function centeredXs(count, spacing) {
  const totalW = (count - 1) * spacing;
  const startX = FORMATION_CENTER_X - totalW / 2;
  const xs = [];
  for (let i = 0; i < count; i++) xs.push(startX + i * spacing);
  return xs;
}

function createEnemyFormation(scene) {
  enemies.clear(true, true);
  enemyFormation = [];
  enemyDirection = 1;
  formationTotalAtWave = 0;

  const layout = [
    { key: 'enemy_flagship', type: 'flagship', count: 2 },
    { key: 'enemy_red',      type: 'red',      count: 6 },
    { key: 'enemy_purple',   type: 'purple',   count: 8 },
    { key: 'enemy_blue',     type: 'blue',     count: 10 },
    { key: 'enemy_blue',     type: 'blue',     count: 10 },
  ];

  layout.forEach((rowDef, row) => {
    enemyFormation[row] = [];
    const xs = centeredXs(rowDef.count, ENEMY_SPACING_X);
    const y  = ENEMY_START_Y + FORMATION_Y_OFFSET + row * ENEMY_SPACING_Y;

    xs.forEach((x, i) => {
      const col = i;
      const e = scene.physics.add.sprite(x, y, rowDef.key);
      e.setScale(0.6);

      e.setData('row', row);
      e.setData('col', col);
      e.setData('type', rowDef.type);

      // home slot
      e.setData('homeX', x);
      e.setData('homeY', y);

      // dive state
      e.setData('state', 'formation'); // formation | diveLoop | diveStraight | returning
      e.setData('loopT', 0);
      e.setData('loopDir', 1);
      e.setData('diveTargetX', x);

      // rotation tracking
      e.setData('prevX', x);
      e.setData('prevY', y);

      e.setRotation(ENEMY_FORMATION_ROT);

      enemies.add(e);
      formationTotalAtWave += 1;
      enemyFormation[row][col] = e;
    });
  });
}

// =================== START SCREEN ===================
function showStartScreen(scene) {
  gamePhase = GAME_PHASE.START;
  countdownInProgress = false;

  // stop gameplay
  scene.physics.pause();
  clearAllBullets();

  // hide game over
  if (gameOverImage) gameOverImage.setVisible(false);
  if (chainStatusText) chainStatusText.setText('');
  if (pohpStatusText) pohpStatusText.setText('');

  // hide player/enemies while waiting
  disablePlayerPhysics(player);
  enemies.children.entries.forEach(e => { e.setActive(false); e.setVisible(false); if (e.body) e.body.enable = false; });

  // show start icon
  if (startIcon) startIcon.destroy();
  startIcon = scene.add.image(400, START_ICON_Y, 'start_icon')
    .setOrigin(0.5)
    .setAlpha(1)
    .setDisplaySize(START_ICON_TARGET_W, START_ICON_TARGET_H)
    .setDepth(9);

  // blink
  scene.tweens.add({
    targets: startIcon,
    alpha: { from: 1, to: 0.25 },
    duration: 600,
    yoyo: true,
    repeat: -1
  });

  // one-time SPACE
  const armStart = () => {
    scene.input.keyboard.once('keydown-SPACE', async () => {
      unlockAudioOnce(scene);

      // --- CHAIN PRE-START GATE (wallet + entry fee) ---
      // This does NOT change gameplay; it only blocks the run from starting until entry is paid (if enabled).
      const setStatus = (t) => { try { if (chainStatusText) chainStatusText.setText(t); } catch (_) {} };

      try {
        if (window.CHAIN && typeof window.CHAIN.preStartGate === 'function') {
          const ok = await window.CHAIN.preStartGate({ setStatus });
          if (!ok) {
            setStatus("CHAIN: cancelled (wallet/entry required). Press SPACE to try again.");
            armStart();
            return;
          }
        } else {
          setStatus("CHAIN: (demo) solana_gate.js not loaded, starting without entry proof.");
        }
      } catch (e) {
        setStatus("CHAIN: " + (e?.message || e) + "  (Press SPACE to retry)");
        armStart();
        return;
      }

      startCountdown(scene);
    });
  };
  armStart();
}

// =================== COUNTDOWN ===================
function startCountdown(scene) {
  if (gamePhase !== GAME_PHASE.START || countdownInProgress) return;
  countdownInProgress = true;
  gamePhase = GAME_PHASE.COUNTDOWN;

  if (startIcon) startIcon.setVisible(false);

  const centerX = 400;
  const centerY = 300;
  const keys = ['count3', 'count2', 'count1'];
  let i = 0;

  function showNext() {
    if (i >= keys.length) {
      countdownSprites.forEach(s => s.destroy());
      countdownSprites = [];
      beginGame(scene);
      return;
    }

    const key = keys[i++];
    const spr = scene.add.image(centerX, centerY, key)
      .setOrigin(0.5)
      .setScale(COUNTDOWN_SIZE_SCALE)
      .setDepth(10)
      .setAlpha(0);

    countdownSprites.push(spr);

    scene.tweens.add({
      targets: spr,
      alpha: 1,
      duration: 250,
      yoyo: true,
      hold: 380,
      onComplete: showNext
    });
  }

  showNext();
}

// =================== BEGIN GAME ===================
function beginGame(scene) {
  countdownInProgress = false;
  gamePhase = GAME_PHASE.RUNNING;

  // remove start icon completely
  if (startIcon) startIcon.destroy();
  startIcon = null;

  // start a new verifiable run session (seeded RNG + recorder)
  POHP_beginRunSession();

  // reset run
  score = 0;
  lives = 3;
  wave  = 1;
  applyWaveDifficulty(wave);

  if (scoreText) scoreText.setText('SCORE: 0');
  if (livesText) livesText.setText('LIVES: 3');
  if (waveText)  waveText.setText('WAVE: 1');

  // rebuild formation + player
  clearAllBullets();
  createEnemyFormation(scene);
  enablePlayerPhysics(player, 400, 550);

  // safety: invuln grace at start
  invulnerabilityTimer = 900;
  respawnTimer = 0;
  playerState = PLAYER_STATE.PLAYING;

  // colliders OFF until updatePlayerState sees invuln
  setColliderActive(enemyBulletPlayerCollider, false);
  setColliderActive(enemyPlayerCollider, false);
  setColliderActive(playerBulletEnemyCollider, true);

  // resume physics
  scene.physics.resume();

  // audio mix
  if (bgm) bgm.setVolume(BGM_VOLUME);
}

// =================== UPDATE ===================
function update(time, delta) {
  const dt = delta / 1000;

  // starfield always
  if (stars) {
    stars.children.entries.forEach(star => {
      star.y += 30 * dt;
      if (star.y > 600) {
        star.y = 0;
        star.x = POHP_vrBetween(0, 800);
      }
    });
  }

    if (pohpDownloadText && gamePhase !== GAME_PHASE.GAME_OVER) pohpDownloadText.setVisible(false);

// GAME OVER input
  if (gamePhase === GAME_PHASE.GAME_OVER) {
    if (pohpDownloadText) pohpDownloadText.setVisible(true);

    if (restartKey && Phaser.Input.Keyboard.JustDown(restartKey)) {
      showStartScreen(mainScene);
    }
    if (submitKey && Phaser.Input.Keyboard.JustDown(submitKey)) {
      submitScoreToChain();
    }
    if (proofKey && Phaser.Input.Keyboard.JustDown(proofKey)) {
      POHP_tryDownloadLatest();
    }

    return;
  }

  // not running -> nothing
  if (gamePhase !== GAME_PHASE.RUNNING) return;

  // Replay override (use recorded delta/time)
  if (POHP_replay.enabled && POHP_replay.loaded) {
    // if we reach end-of-log but game still running, end safely
    if (POHP_replay.frame >= POHP_replay.masks.length) {
      gameOver();
      return;
    }
    const sim = POHP_replayOverrideTimeDelta(time, delta);
    time = sim.time;
    delta = sim.delta;
  }

  // advance input frame (live: read+record, replay: feed from package)
  POHP_advanceInputsAndRecord(delta);

  // timers
  if (respawnTimer > 0) respawnTimer -= delta;
  if (invulnerabilityTimer > 0) invulnerabilityTimer -= delta;

  // last life aura (only visual)
  if (boomAura && player) {
    const show = (lives === 1) && player.active && (playerState === PLAYER_STATE.PLAYING);
    boomAura.setVisible(show);
    if (show) {
      boomAura.setPosition(player.x, player.y);
      boomAura.setAlpha(0.35 + 0.25 * (Math.sin(time / 70) > 0 ? 1 : 0));
    }
  }

  updatePlayerState(time, delta);
  updateEnemyFormation(delta);
  updateDivingEnemies(delta);
  enemyShooting();
  cleanupBullets();

  // audio loops depending on state
  const formationCount = enemies.children.entries.filter(e => e.active && e.getData('state') === 'formation').length;
  const divingCount = enemies.children.entries.filter(e => e.active && (e.getData('state') === 'diveLoop' || e.getData('state') === 'diveStraight')).length;

  setLoopVolume(sfxEnemyMoveLoop, formationCount > 0 ? SFX_ENEMY_MOVE_VOL : 0);
  setLoopVolume(sfxEnemyDiveLoop, divingCount > 0 ? SFX_ENEMY_DIVE_VOL : 0);
}

// =================== PLAYER FSM ===================
function updatePlayerState(time, delta) {
  switch (playerState) {
    case PLAYER_STATE.PLAYING:
      if (player && player.active) {
        // movement (from unified input state: live or replay)
        if (POHP_input.left && player.x > 0) player.setVelocityX(-220);
        else if (POHP_input.right && player.x < 800) player.setVelocityX(220);
        else player.setVelocityX(0);

        // shoot (edge-triggered, deterministic)
        if (POHP_input.shootJust) shootPlayerBullet();

        // invulnerability blink
        if (invulnerabilityTimer > 0) {
          player.setAlpha((Math.sin(time / 50) > 0) ? 0.45 : 1);
          setColliderActive(enemyBulletPlayerCollider, false);
          setColliderActive(enemyPlayerCollider, false);
        } else {
          player.setAlpha(1);
          setColliderActive(enemyBulletPlayerCollider, true);
          setColliderActive(enemyPlayerCollider, true);
        }
      }
      break;

    case PLAYER_STATE.DYING:
      if (respawnTimer <= 0) {
        playerState = PLAYER_STATE.RESPAWNING;
        respawnTimer = RESPAWN_DELAY;
      }
      break;

    case PLAYER_STATE.RESPAWNING:
      if (respawnTimer <= 0) {
        if (lives > 0) {
          enablePlayerPhysics(player, 400, 550);
          invulnerabilityTimer = INVULN_DURATION;
          setColliderActive(enemyBulletPlayerCollider, false);
          setColliderActive(enemyPlayerCollider, false);
          playerState = PLAYER_STATE.PLAYING;
        } else {
          // safety: should not happen here, but keep
          gameOver();
        }
      }
      break;

    case PLAYER_STATE.GAME_OVER:
      break;
  }
}

// =================== PLAYER SHOOTING ===================
function shootPlayerBullet() {
  if (gamePhase !== GAME_PHASE.RUNNING) return;
  if (playerState !== PLAYER_STATE.PLAYING) return;
  if (!player || !player.active) return;

  const activeCount = playerBullets.children.entries.filter(b => b.active).length;
  if (activeCount >= MAX_PLAYER_BULLETS_ONSCREEN) return;

  const bullet = playerBullets.getFirstDead(false);
  if (!bullet) return;

  if (sfxPlayerShoot) sfxPlayerShoot.play({ volume: SFX_SHOOT_VOLUME });

  bullet.setActive(true);
  bullet.setVisible(true);
  bullet.setScale(0.6);

  const x = player.x;
  const y = player.y - 20;
  bullet.setPosition(x, y);

  if (bullet.body) {
    bullet.body.enable = true;
    bullet.body.reset(x, y);
    bullet.body.setVelocity(0, -400);
  }
}

// =================== ENEMY FORMATION MOVEMENT ===================
function updateEnemyFormation(delta) {
  if (!enemyFormation.length) return;
  const dt = delta / 1000;

  let moveDown = false;
  let leftmostX = 800, rightmostX = 0, lowestY = 0;
  let found = false;

  for (let row = 0; row < enemyFormation.length; row++) {
    if (!enemyFormation[row]) continue;
    for (let col = 0; col < enemyFormation[row].length; col++) {
      const e = enemyFormation[row][col];
      if (!e || !e.active) continue;
      if (e.getData('state') !== 'formation') continue;
      found = true;
      leftmostX = Math.min(leftmostX, e.x);
      rightmostX = Math.max(rightmostX, e.x);
      lowestY = Math.max(lowestY, e.y);
    }
  }

  if (found) {
    if (rightmostX >= 750 || leftmostX <= 50) {
      enemyDirection *= -1;
      moveDown = true;
    }
  }

  const startY = ENEMY_START_Y + FORMATION_Y_OFFSET;
  const maxY = 500;
  let progress = (lowestY - startY) / (maxY - startY);
  progress = Phaser.Math.Clamp(progress, 0, 1);

  const speedMultiplier = 1.0 + progress * 1.4 // 1x -> 3x
  const ar = aliveRatioNow();
  const thinMul = 1 + (1 - ar) * THIN_OUT_SPEED_UP;

  const currentSpeed = enemySpeedBase * speedMultiplier * thinMul;

  for (let row = 0; row < enemyFormation.length; row++) {
    if (!enemyFormation[row]) continue;
    for (let col = 0; col < enemyFormation[row].length; col++) {
      const e = enemyFormation[row][col];
      if (!e || !e.active) continue;

      const state = e.getData('state');
      if (state !== 'formation') continue;

      e.x += currentSpeed * enemyDirection * dt;
      if (moveDown) e.y += 12;

      e.setData('homeX', e.x);
      e.setData('homeY', e.y);

      // settle rotation
      e.rotation = Phaser.Math.Angle.RotateTo(e.rotation, ENEMY_FORMATION_ROT, 0.15);

      // dive chance
      const type = e.getData('type') || 'blue';
      let diveChance = enemyDiveBaseChance;
      if (type === 'red') diveChance *= 1.4;
      if (type === 'purple') diveChance *= 1.2;
      if (type === 'flagship') diveChance *= (progress > 0.6 ? 1.6 : 0.2);

      // more aggressive when lower + thinned out
      diveChance *= (1.0 + progress * 2.0) * (0.9 + 0.1 * thinMul);

      if (POHP_grFloat() < diveChance) startEnemyDive(e);
    }
  }
}

// =================== DIVE LOGIC ===================
function startEnemyDive(enemy) {
  const state = enemy.getData('state');
  if (state !== 'formation') return;

  const divingCount = enemies.children.entries.filter(e =>
    e.active && (e.getData('state') === 'diveLoop' || e.getData('state') === 'diveStraight')
  ).length;
  if (divingCount >= MAX_DIVING_ENEMIES) return;

  enemy.setData('state', 'diveLoop');
  enemy.setData('loopT', 0);

  const dir = (enemy.x < 400) ? -1 : 1;
  const radius = 85;
  const cx = enemy.x + dir * radius;
  const cy = enemy.y + 20;

  enemy.setData('loopDir', dir);
  enemy.setData('loopRadius', radius);
  enemy.setData('loopCenterX', cx);
  enemy.setData('loopCenterY', cy);

  const targetX = (player && player.active)
    ? POHP_grBetween(player.x - 140, player.x + 140)
    : POHP_grBetween(150, 650);

  enemy.setData('diveTargetX', Phaser.Math.Clamp(targetX, 40, 760));

  // reset prev for rotation by velocity
  enemy.setData('prevX', enemy.x);
  enemy.setData('prevY', enemy.y);
}

function setEnemyRotationFromVelocity(e, dt) {
  const st = e.getData('state');
  const d = (typeof dt === 'number' && dt > 0) ? dt : 0.016;

  // Update last pos every frame so velocity calc (if used) stays stable
  const lastX = e.getData('lastX');
  const lastY = e.getData('lastY');
  if (lastX === undefined || lastY === undefined) {
    e.setData('lastX', e.x);
    e.setData('lastY', e.y);
    // still force correct facing on first tick
    if (st === 'diveLoop' || st === 'diveStraight') e.rotation = ENEMY_DIVE_ROT;
    else e.rotation = ENEMY_FORMATION_ROT;
    return;
  }

  const vx = e.x - lastX;
  const vy = e.y - lastY;

  e.setData('lastX', e.x);
  e.setData('lastY', e.y);

  // === Classic Galaxian-style facing rule ===
  // Attack: always face DOWN
  if (st === 'diveLoop' || st === 'diveStraight') {
    e.rotation = Phaser.Math.Angle.RotateTo(e.rotation, ENEMY_DIVE_ROT, ENEMY_ROT_SPEED_DIVE * d);
    return;
  }

  // Formation / returning: rotate back to formation facing
  if (st === 'formation') {
    e.rotation = Phaser.Math.Angle.RotateTo(e.rotation, ENEMY_FORMATION_ROT, ENEMY_ROT_SPEED_RETURN * d);
    return;
  }
  if (st === 'returning') {
    const want = Phaser.Math.Angle.Wrap(ENEMY_RETURN_ROT);
    e.rotation = Phaser.Math.Angle.RotateTo(e.rotation, want, ENEMY_ROT_SPEED_RETURN * d);
    return;
  }

  // Fallback (if you add other states later): face movement direction
  if (vx !== 0 || vy !== 0) {
    const ang = Math.atan2(vy, vx) + ENEMY_ROT_OFFSET;
    e.rotation = Phaser.Math.Angle.RotateTo(e.rotation, ang, ENEMY_ROT_SPEED_RETURN * d);
  }
}

function updateDivingEnemies(delta) {
  const dt = delta / 1000;
  const sMul = waveSpeedMul(wave);
  const ar = aliveRatioNow();
  const thinMul = 1 + (1 - ar) * 0.35;

  enemies.children.entries.forEach(e => {
    if (!e.active) return;
    const state = e.getData('state');

    if (state === 'diveLoop') {
      let t = (e.getData('loopT') || 0) + dt * (1.25 * ENEMY_SPEED_FACTOR * sMul * thinMul);
      if (t > 1) t = 1;
      e.setData('loopT', t);

      const dir = e.getData('loopDir') || 1;
      const radius = e.getData('loopRadius') || 85;
      const cx = e.getData('loopCenterX') || e.x;
      const cy = e.getData('loopCenterY') || (e.y + 40);

      const tEase = Phaser.Math.Easing.Sine.InOut(t);
      const angle = -Math.PI / 2 + dir * (Math.PI * 1.4) * tEase;

      const x = cx + Math.cos(angle) * radius;
      const y = cy + Math.sin(angle) * radius;

      e.setPosition(x, y);
      setEnemyRotationFromVelocity(e, dt); // ✅ classic “turn” feel

      if (t >= 1) e.setData('state', 'diveStraight');

    } else if (state === 'diveStraight') {
      const vxMax = 150 * ENEMY_SPEED_FACTOR * sMul * thinMul;
      const vy    = 145 * ENEMY_SPEED_FACTOR * sMul * thinMul;

      const targetX = e.getData('diveTargetX') || e.x;
      const dx = targetX - e.x;
      const vx = Phaser.Math.Clamp(dx * 2.9, -vxMax, vxMax);

      e.x += vx * dt;
      e.y += vy * dt;

      setEnemyRotationFromVelocity(e, dt); // ✅ keep facing motion (down during dive)

      if (e.y > 650) {
        const homeX = e.getData('homeX') || e.x;
        const homeY = e.getData('homeY') || 120;

        e.x = homeX;
        e.y = -40;
        e.setData('returnY', homeY);
        e.setData('state', 'returning');

        e.setData('prevX', e.x);
        e.setData('prevY', e.y);
      }

    } else if (state === 'returning') {
      const returnY = e.getData('returnY') || 120;
      const returnSpeed = 170 * ENEMY_SPEED_FACTOR * sMul;

      e.y += returnSpeed * dt;

      // face down while returning
      setEnemyRotationFromVelocity(e, dt);

      if (e.y >= returnY) {
        e.y = returnY;
        e.setData('state', 'formation');
        e.setRotation(ENEMY_FORMATION_ROT);
      }
    }
  });
}

// =================== ENEMY SHOOTING ===================
function enemyShooting() {
  const formationEnemies = enemies.children.entries.filter(e => e.active && e.getData('state') === 'formation');
  const divingEnemies = enemies.children.entries.filter(e => e.active && (e.getData('state') === 'diveLoop' || e.getData('state') === 'diveStraight'));

  const ar = aliveRatioNow();
  const thinRateMul = 1 + (1 - ar) * THIN_OUT_RATE_UP;

  const formChance = enemyBulletBaseChance * thinRateMul;
  if (formationEnemies.length > 0 && POHP_grFloat() < formChance) {
    shootEnemyBullet(POHP_grPick(formationEnemies));
  }

  const diveChance = enemyBulletBaseChance * 1.9 * (0.85 + 0.15 * thinRateMul);
  if (divingEnemies.length > 0 && POHP_grFloat() < diveChance) {
    shootEnemyBullet(POHP_grPick(divingEnemies));
  }
}

function shootEnemyBullet(shooter) {
  const bullet = enemyBullets.getFirstDead(false);
  if (!bullet) return;

  bullet.setActive(true);
  bullet.setVisible(true);
  bullet.setScale(0.5);

  const x = shooter.x;
  const y = shooter.y + 18;
  bullet.setPosition(x, y);

  const ar = aliveRatioNow();
  const thinMul = 1 + (1 - ar) * THIN_OUT_BULLET_UP;
  const bMul = waveBulletMul(wave);

  const vMin = 500 * ENEMY_SPEED_FACTOR * bMul * thinMul;
  const vMax = 550 * ENEMY_SPEED_FACTOR * bMul * thinMul;
  const vY = POHP_grFloatBetween(vMin, vMax);

  if (bullet.body) {
    bullet.body.enable = true;
    bullet.body.reset(x, y);
    bullet.body.setVelocity(0, vY);
  }
}

// =================== COLLISIONS ===================
function hitEnemy(bullet, enemy) {
  disableBullet(bullet);

  if (enemy && enemy.active) {
    enemy.setActive(false);
    enemy.setVisible(false);
    if (enemy.body) {
      enemy.body.enable = false;
      enemy.body.setVelocity(0, 0);
    }
  }

  const type = enemy.getData('type') || 'blue';
  const points = ENEMY_SCORES[type] || ENEMY_SCORES.blue;

  // bonus for killing while diving (risk reward!)
  const st = enemy.getData('state');
  const diveBonus = (st === 'diveLoop' || st === 'diveStraight') ? Math.floor(points * 0.35) : 0;

  score += (points + diveBonus);
  if (scoreText) scoreText.setText('SCORE: ' + score);

  const gotNewHi = maybeUpdateHighScore();
  if (gotNewHi && highScoreText) {
    highScoreText.setText('HI-SCORE: ' + highScore);
    saveScores();
  }

  const scene = enemy.scene;
  const boom = scene.add.sprite(enemy.x, enemy.y, 'explosion');
  boom.setScale(1.0);
  scene.time.delayedCall(300, () => boom.destroy());

  // infinite waves
  if (enemies.countActive(true) === 0) {
    // wave clear bonus
    const clearBonus = 250 + (wave * 25);
    score += clearBonus;
    if (scoreText) scoreText.setText('SCORE: ' + score);

    wave += 1;
    applyWaveDifficulty(wave);
    if (waveText) waveText.setText('WAVE: ' + wave);

    scene.time.delayedCall(750, () => createEnemyFormation(scene));
  }
}

function spawnPlayerHitFX(scene, x, y) {
  // boom.png effect (your request)
  const fx = scene.add.image(x, y, 'boom').setOrigin(0.5).setScale(1.15).setDepth(20);
  fx.setAlpha(1);
  scene.tweens.add({
    targets: fx,
    scale: 0.15,
    alpha: 0,
    duration: 420,
    onComplete: () => fx.destroy()
  });
}

function hitPlayer(bulletOrEnemy, playerObj) {
  if (gamePhase !== GAME_PHASE.RUNNING) return;
  if (playerState !== PLAYER_STATE.PLAYING) return;
  if (!playerObj || !playerObj.active) return;
  if (invulnerabilityTimer > 0) return;

  // disable bullet (if bullet)
  if (bulletOrEnemy) {
    const isBullet = enemyBullets.contains(bulletOrEnemy) || playerBullets.contains(bulletOrEnemy);
    if (isBullet) disableBullet(bulletOrEnemy);
  }

  lives -= 1;
  if (lives < 0) lives = 0;
  if (livesText) livesText.setText('LIVES: ' + lives);

  const scene = playerObj.scene;

  if (sfxHitShip) sfxHitShip.play({ volume: SFX_HIT_VOLUME, rate: 0.85 });

  spawnPlayerHitFX(scene, playerObj.x, playerObj.y);

  disablePlayerPhysics(playerObj);

  setColliderActive(enemyBulletPlayerCollider, false);
  setColliderActive(enemyPlayerCollider, false);

  respawnTimer = RESPAWN_DELAY;

  if (lives > 0) {
    playerState = PLAYER_STATE.DYING;
  } else {
    playerState = PLAYER_STATE.GAME_OVER;
    scene.time.delayedCall(RESPAWN_DELAY, () => gameOver());
  }
}

// =================== BULLETS HELPERS ===================
function disableBullet(bullet) {
  if (!bullet || !bullet.active) return;
  bullet.setActive(false);
  bullet.setVisible(false);
  bullet.setPosition(-100, -100);
  if (bullet.body) {
    bullet.body.enable = false;
    bullet.body.setVelocity(0, 0);
  }
}

function cleanupBullets() {
  playerBullets.children.entries.forEach(b => { if (b.active && b.y < -20) disableBullet(b); });
  enemyBullets.children.entries.forEach(b => { if (b.active && b.y > 620) disableBullet(b); });
}

function clearAllBullets() {
  if (playerBullets) playerBullets.children.entries.forEach(b => disableBullet(b));
  if (enemyBullets) enemyBullets.children.entries.forEach(b => disableBullet(b));
}

// =================== GAME OVER ===================
function gameOver() {
  gamePhase = GAME_PHASE.GAME_OVER;
  playerState = PLAYER_STATE.GAME_OVER;

  // === Proof-of-High-Play package ===
  // Live: export runPackage.json automatically
  // Replay: verify recomputed score vs expected
  if (POHP_replay.enabled && POHP_replay.loaded) {
    const okScore = (score === POHP_replay.expectedScore);
    const okWave  = (wave === POHP_replay.expectedWave);
    const hashNote = (POHP_replay.hashOk === null) ? "" : (POHP_replay.hashOk ? "hash OK" : "hash MISMATCH");
    if (pohpStatusText) pohpStatusText.setText(
      "REPLAY VERIFY: " + ((okScore && okWave) ? "PASS ✅" : "FAIL ❌") +
      "\nexpected score " + POHP_replay.expectedScore + " / got " + score +
      "\nexpected wave " + POHP_replay.expectedWave + " / got " + wave +
      (hashNote ? ("\n" + hashNote) : "")
    );
  } else {
    // Build runPackage (async). Download is triggered by user gesture (press P) to avoid browser blocking.
    POHP_finalizeRunPackageOnGameOver(score, wave).then(() => {
      if (pohpStatusText) pohpStatusText.setText("PROOF READY ✅  Press P to download runPackage.json  |  Verify: ?replay=1");
    }).catch(() => {
      if (pohpStatusText) pohpStatusText.setText("PROOF ERROR ❌  (open console)");
    });
  }

  // finalize scores (skip persistence during replay verification)
  if (!(POHP_replay.enabled && POHP_replay.loaded)) {
    maybeUpdateHighScore();
    pushTopScore(score, wave);
    saveScores();
  } else {
    // still update hi-score display locally (no write)
    maybeUpdateHighScore();
  }

  if (highScoreText) highScoreText.setText('HI-SCORE: ' + highScore);
  if (topText) topText.setText(formatTopScores());

  // stop gameplay
  if (player) disablePlayerPhysics(player);
  clearAllBullets();

  setColliderActive(enemyBulletPlayerCollider, false);
  setColliderActive(enemyPlayerCollider, false);
  setColliderActive(playerBulletEnemyCollider, false);

  respawnTimer = 0;
  invulnerabilityTimer = 0;

  // show game over
  if (gameOverImage) gameOverImage.setVisible(true);

  if (chainStatusText) chainStatusText.setText("R = RESTART   B = SUBMIT SCORE (CHAIN)   P = DOWNLOAD PROOF");

  // audio: keep bgm low, loops silent
  if (bgm) bgm.setVolume(BGM_VOLUME * 0.65);
  if (sfxEnemyMoveLoop) sfxEnemyMoveLoop.setVolume(0);
  if (sfxEnemyDiveLoop) sfxEnemyDiveLoop.setVolume(0);

  mainScene.physics.pause();
}

// =================== START GAME ===================
game = new Phaser.Game(config);
