// src/chain/solana_gate.js
(() => {
  const RPC_URL = "https://api.devnet.solana.com";
  const POOL_PUBKEY = "PUT_POOL_PUBKEY_HERE";
  const NORMAL_FEE_LAMPORTS = 290_000;
  const BOT_MULTIPLIER = 10;
  const HUMAN_PASS_MINT = "";
  const REQUIRE_REAL_POOL = true;

  function detectProvider() {
    return (window.phantom && window.phantom.solana) ? window.phantom.solana : window.solana;
  }
  function isPlaceholderPool(pool) {
    if (!pool) return true;
    return pool === "PUT_POOL_PUBKEY_HERE" || pool.includes("PUT_POOL");
  }
  async function ensureWeb3() {
    if (!window.solanaWeb3) throw new Error("solanaWeb3 missing. Check index.html CDN script for @solana/web3.js.");
    return window.solanaWeb3;
  }
  async function connectWallet(provider) {
    if (provider && provider.publicKey) return provider.publicKey.toString();
    const res = await provider.connect();
    return res.publicKey.toString();
  }
  async function hasHumanPass(connection, ownerPubkeyStr) {
    if (!HUMAN_PASS_MINT) return false;
    const web3 = await ensureWeb3();
    const owner = new web3.PublicKey(ownerPubkeyStr);
    const mint = new web3.PublicKey(HUMAN_PASS_MINT);
    const resp = await connection.getParsedTokenAccountsByOwner(owner, { mint });
    for (const it of resp.value || []) {
      const amountStr = it.account?.data?.parsed?.info?.tokenAmount?.amount;
      const amount = amountStr ? parseInt(amountStr, 10) : 0;
      if (amount > 0) return true;
    }
    return false;
  }
  async function payEntry(connection, provider, ownerPubkeyStr, lamports, setStatus) {
    const web3 = await ensureWeb3();
    const toPubkey = new web3.PublicKey(POOL_PUBKEY);
    const fromPubkey = new web3.PublicKey(ownerPubkeyStr);
    const latest = await connection.getLatestBlockhash("confirmed");
    const tx = new web3.Transaction();
    tx.feePayer = fromPubkey;
    tx.recentBlockhash = latest.blockhash;
    tx.add(web3.SystemProgram.transfer({ fromPubkey, toPubkey, lamports }));
    setStatus?.(`CHAIN: sign entry (${lamports} lamports) ...`);
    const signed = await provider.signTransaction(tx);
    setStatus?.(`CHAIN: sending...`);
    const signature = await connection.sendRawTransaction(signed.serialize(), { skipPreflight: false });
    setStatus?.(`CHAIN: confirming...`);
    await connection.confirmTransaction({ signature, blockhash: latest.blockhash, lastValidBlockHeight: latest.lastValidBlockHeight }, "confirmed");
    let slot = null;
    try {
      const st = await connection.getSignatureStatus(signature, { searchTransactionHistory: true });
      slot = st && st.value ? st.value.slot : null;
    } catch (_) {}
    return { signature, slot };
  }
  async function injectToPOHP({ playerPubkey, feeLamports, entrySig, entrySlot, setStatus }) {
    if (!window.POHP) {
      setStatus?.("POHP: not ready yet (main.js not loaded).");
      return;
    }
    window.POHP.setPlayerPubkey(playerPubkey);
    window.POHP.setEntryProof({ feeLamports, entrySig, entrySlot });
    setStatus?.(`POHP: bound pubkey + entry proof.`);
  }

  window.CHAIN = {
    async preStartGate({ setStatus } = {}) {
      const provider = detectProvider();
      if (!provider) throw new Error("No Solana wallet found (install Phantom).");
      if (!provider.signTransaction) throw new Error("Wallet does not support signTransaction().");
      if (REQUIRE_REAL_POOL && isPlaceholderPool(POOL_PUBKEY)) {
        throw new Error("POOL_PUBKEY is placeholder. Set it in src/chain/solana_gate.js.");
      }

      setStatus?.("CHAIN: connecting wallet...");
      let playerPubkey;
      try { playerPubkey = await connectWallet(provider); }
      catch (_) { return false; }

      const web3 = await ensureWeb3();
      const connection = new web3.Connection(RPC_URL, "confirmed");

      let feeLamports = NORMAL_FEE_LAMPORTS;
      try {
        const hasPass = await hasHumanPass(connection, playerPubkey);
        if (!hasPass) feeLamports = NORMAL_FEE_LAMPORTS * BOT_MULTIPLIER;
        setStatus?.(hasPass ? "CHAIN: Human Pass detected (normal fee)." : "CHAIN: No Human Pass (bot fee).");
      } catch (_) {
        setStatus?.("CHAIN: Human Pass check failed (using normal fee).");
      }

      let entrySig = "";
      let entrySlot = null;

      if (!isPlaceholderPool(POOL_PUBKEY)) {
        try {
          const paid = await payEntry(connection, provider, playerPubkey, feeLamports, setStatus);
          entrySig = paid.signature;
          entrySlot = paid.slot;
        } catch (e) {
          setStatus?.(`CHAIN: entry failed (${e?.message || e})`);
          return false;
        }
      } else {
        setStatus?.("CHAIN: pool not set (demo mode, no entry payment).");
        feeLamports = 0;
      }

      await injectToPOHP({ playerPubkey, feeLamports, entrySig, entrySlot, setStatus });
      setStatus?.("CHAIN: entry ok.");
      return true;
    },
  };
})();
