# DOG KING (template)

- `src/main.js` : Phaser game + POHP package builder (gameplay unchanged)
- `src/chain/solana_gate.js` : Phantom connect + entry fee payment, injects `player_pubkey / fee_lamports / entry_sig / entry_slot` into POHP
- `tools/dev_server.py` : serve static + optional POST `/submit-score` to save run packages under `runs/`

## Run
```powershell
cd "C:\Users\spirc\Desktop\DOG KING"
python tools\dev_server.py 8000
```
Open: http://localhost:8000/

## IMPORTANT
Edit `src/chain/solana_gate.js`:
- `POOL_PUBKEY = "..."`  (your Pool PDA / receiving address)
- optionally `HUMAN_PASS_MINT = "..."`  (mint of your Human Pass NFT)
